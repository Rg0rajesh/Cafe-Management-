<?php
// Admin view to see login history
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cafe_app";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 1: Create login log table if not exists
$conn->query("
    CREATE TABLE IF NOT EXISTS user_logins (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES cafe_users(id)
    )
");

// Step 2: Create or replace view with full_name
$conn->query("
    CREATE OR REPLACE VIEW user_login_view AS
    SELECT 
        u.id,
        CONCAT(u.first_name, ' ', u.last_name) AS full_name,
        u.email,
        'xxxxxx' AS password_masked,
        l.login_time
    FROM cafe_users u
    JOIN user_logins l ON u.id = l.user_id
    ORDER BY l.login_time DESC
");

// Step 3: Fetch from view
$result = $conn->query("SELECT * FROM user_login_view");
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Login Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&family=Courgette&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: white;
            font-family: 'Arial', sans-serif;
            padding: 0;
            margin: 0;
        }

        h1 {
            font-family: 'Bungee Shade', cursive;
            text-align: center;
            font-size: 48px;
            color: limegreen;
            text-shadow: 3px 3px #8080ff;
            margin-top: 30px;
        }

        .table-container {
            width: 90%;
            margin: 40px auto;
            background: #9b5de5;
            border-radius: 30px;
            padding: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            border-radius: 20px;
            overflow: hidden;
        }

        th {
            background-color: #7b2cbf;
            color: white;
            font-size: 20px;
            font-family: 'Arial Black', Gadget, sans-serif;
            padding: 15px;
            text-align: left;
        }

        td {
            padding: 15px;
            font-family: 'Courier New', monospace;
            font-size: 16px;
            border-bottom: 1px solid #ccc;
            font-weight: bold;
        }

        tr:hover {
            background-color: #f3f3f3;
        }

        .home-link {
            position: absolute;
            top: 20px;
            right: 40px;
            font-family: 'Arial Black', sans-serif;
            font-size: 18px;
            color: black;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <a class="home-link" href="admin.html">home</a>
    <h1>USER LOGIN DETAILS</h1>

    <div class="table-container">
        <?php if ($result->num_rows > 0): ?>
            <table>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Login Time</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['full_name']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['password_masked']) ?></td>
                        <td><?= htmlspecialchars($row['login_time']) ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p style="text-align:center; font-weight:bold;">No users have logged in yet.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php $conn->close(); ?>
