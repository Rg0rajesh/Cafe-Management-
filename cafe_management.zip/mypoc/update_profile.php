<?php
// Start output buffering
ob_start();

// Configure error handling
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/php_errors.log');

error_log("Starting update_profile.php");

// Start session
session_start();
if (!isset($_SESSION['user'])) {
    error_log("Unauthorized access to update_profile.php");
    ob_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$user = $_SESSION['user'];
$email = $user['email'];
error_log("User session valid: " . $email);

// DB connection
$conn = new mysqli("localhost", "root", "", "cafe_app");
if ($conn->connect_error) {
    error_log("DB connection failed: " . $conn->connect_error);
    ob_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}
error_log("Database connected");

// Get current profile image if any
$profile_image = $user['profile_image'] ?? null;

// Handle profile image upload
if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
    $upload_dir = __DIR__ . '/Uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    $ext = strtolower(pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])) {
        ob_clean();
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Invalid image format']);
        exit;
    }

    $profile_image = 'Uploads/' . uniqid() . '.' . $ext;
    if (!move_uploaded_file($_FILES['profile_image']['tmp_name'], __DIR__ . '/' . $profile_image)) {
        ob_clean();
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Image upload failed']);
        exit;
    }
}

// Get form data
$city = trim($_POST['city'] ?? '');
$state = trim($_POST['state'] ?? '');
$country = trim($_POST['country'] ?? '');
$area = trim($_POST['area'] ?? '');
$pincode = trim($_POST['pincode'] ?? '');

// Update query
$stmt = $conn->prepare("
    UPDATE cafe_users 
    SET profile_image = ?, country = ?, state = ?, city = ?, area = ?, pincode = ? 
    WHERE email = ?
");
$stmt->bind_param("sssssss", $profile_image, $country, $state, $city, $area, $pincode, $email);

if (!$stmt->execute()) {
    error_log("Update failed: " . $stmt->error);
    ob_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Update failed']);
    exit;
}

// Refresh session with specific fields
$stmt = $conn->prepare("
    SELECT id, first_name, last_name, phone, email, profile_image, area, city, state, country, pincode 
    FROM cafe_users 
    WHERE email = ?
");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
if ($result && $result->num_rows > 0) {
    $_SESSION['user'] = $result->fetch_assoc();
}

$stmt->close();
$conn->close();

// Success
ob_clean();
header('Content-Type: application/json');
echo json_encode(['success' => true]);
error_log("Profile updated successfully");

exit;
?>