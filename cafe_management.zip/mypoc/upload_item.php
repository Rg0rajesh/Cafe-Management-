<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cafe_app";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create table if not exists
$createTableSQL = "CREATE TABLE IF NOT EXISTS menu_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(50) NOT NULL,
    item_name VARCHAR(255) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($createTableSQL);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $category   = $_POST['category'] ?? null;
    $item_name  = $_POST['item_name'] ?? null;
    $price      = $_POST['price'] ?? null;
    $image      = $_FILES['image'] ?? null;

    // Basic validation
    if (!$category || !$item_name || !$price || !$image) {
        echo "All fields are required.";
        exit;
    }

    $target_dir = "uploads/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $image_name = basename($image["name"]);
    $filename = time() . "_" . $image_name;
    $target_file = $target_dir . $filename;

    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png'];

    if (in_array($imageFileType, $allowed)) {
        if (move_uploaded_file($image["tmp_name"], $target_file)) {
            $stmt = $conn->prepare("INSERT INTO menu_items (category, item_name, price, image_path) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssds", $category, $item_name, $price, $filename);

            if ($stmt->execute()) {
                echo "success";
            } else {
                echo "Database error: " . $stmt->error;
            }
        } else {
            echo "Failed to upload image.";
        }
    } else {
        echo "Only JPG, JPEG, PNG files allowed.";
    }
}

$conn->close();
?>
