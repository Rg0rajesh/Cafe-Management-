<?php
header("Content-Type: application/json");

// Database config
$host = "localhost";
$dbname = "cafe_app";
$username = "root";
$password = ""; // Update if your DB has a password

// Create connection to MySQL server
$conn = new mysqli($host, $username, $password);

// Check connection
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed."]);
    exit();
}

// Create database if it doesn't exist
$conn->query("CREATE DATABASE IF NOT EXISTS $dbname");

// Select the database
$conn->select_db($dbname);

// Create table if it doesn't exist
$createTableSQL = "
CREATE TABLE IF NOT EXISTS cafe_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    phone VARCHAR(15) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    profile_image VARCHAR(255) DEFAULT NULL,
    city VARCHAR(100) DEFAULT NULL,
    state VARCHAR(100) DEFAULT NULL,
    country VARCHAR(100) DEFAULT NULL,
    pincode VARCHAR(20) DEFAULT NULL,
    area VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if (!$conn->query($createTableSQL)) {
    echo json_encode(["success" => false, "message" => "Failed to create users table."]);
    exit();
}

// Create or replace the public view (no password included)
$createViewSQL = "CREATE OR REPLACE VIEW user_public_view AS
    SELECT id, first_name, last_name, phone, email, profile_image, city, state, country, pincode, area, created_at
    FROM cafe_users";
$conn->query($createViewSQL);

// Get and sanitize form inputs
$firstName = trim($_POST['first_name']);
$lastName = trim($_POST['last_name']);
$phone = trim($_POST['phone']);
$email = trim($_POST['email']);
$password = $_POST['password'];
$confirmPassword = $_POST['confirm_password'];

// Validate inputs
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["success" => false, "message" => "Invalid email format."]);
    exit();
}

if (!preg_match("/^[6-9]\d{9}$/", $phone)) {
    echo json_encode(["success" => false, "message" => "Invalid phone number."]);
    exit();
}

if ($password !== $confirmPassword) {
    echo json_encode(["success" => false, "message" => "Passwords do not match."]);
    exit();
}

if (!preg_match("/^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#]).{8,}$/", $password)) {
    echo json_encode(["success" => false, "message" => "Password must be at least 8 characters, contain an uppercase letter, a number, and a special character."]);
    exit();
}

// Check if email or phone already exists
$checkQuery = $conn->prepare("SELECT id FROM cafe_users WHERE email = ? OR phone = ?");
$checkQuery->bind_param("ss", $email, $phone);
$checkQuery->execute();
$checkQuery->store_result();

if ($checkQuery->num_rows > 0) {
    echo json_encode(["success" => false, "message" => "Email or phone already registered."]);
    exit();
}
$checkQuery->close();

// Hash password
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

// Insert new user
$insertQuery = $conn->prepare("INSERT INTO cafe_users (first_name, last_name, phone, email, password_hash) VALUES (?, ?, ?, ?, ?)");
$insertQuery->bind_param("sssss", $firstName, $lastName, $phone, $email, $passwordHash);

if ($insertQuery->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to create account."]);
}

$insertQuery->close();
$conn->close();
?>