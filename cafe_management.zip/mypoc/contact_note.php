<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Notes</title>
    <style>
        <style>
    body {
        background-color: #f0f0f0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 0;
    }

    .top-bar {
        
       
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
        
    }

    .form-heading {
        font-size: 50px;
        font-weight: bold;
        color: lime;
        text-shadow: 2px 2px #9dc3e6;
        font-family: 'Impact', sans-serif;
        margin: 0;
    }

    .home-link {
        position: absolute;
        right: 30px;
        top: 30px;
        background-color: black;
        color: white;
        text-decoration: none;
        padding: 10px 20px;
        border-radius: 12px;
        font-size: 18px;
        font-weight: bold;
        transition: background-color 0.3s ease;
    }

    .home-link:hover {
        background-color: #333;
    }

    .contact-form {
        margin: 30px auto;
        background: #8e5df7;
        border-radius: 30px;
        padding: 30px;
        width: 90%;
        max-width: 900px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
    }

    .message-box {
        background: white;
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
    }

    .message-box p {
        margin: 8px 0;
        font-size: 18px;
        line-height: 1.5;
    }

    .message-box strong {
        color: #222;
    }

    @media (max-width: 600px) {
        .form-heading {
            font-size: 36px;
        }

        .home-link {
            top: 20px;
            right: 20px;
            font-size: 16px;
            padding: 8px 16px;
           background-color:orange;
        }

        .contact-form {
            padding: 20px;
        }

        .message-box p {
            font-size: 16px;
        }
    }
    
</style>

    </style>
</head>
<body>

    <div class="top-bar">
        <h1 class="form-heading">NOTE FROM CUSTOMER</h1>
       <a href="admin.html" class="home-link">Home</a>
    </div>

    <div class="contact-form">
        <?php
        // Database connection
        $conn = new mysqli("localhost", "root", "", "cafe_app");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch messages
        $sql = "SELECT name, email, message FROM contact_messages ORDER BY id DESC";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='message-box'>";
                echo "<p><strong>Name:</strong> " . htmlspecialchars($row['name']) . "</p>";
                echo "<p><strong>Email:</strong> " . htmlspecialchars($row['email']) . "</p>";
                echo "<p><strong>Message:</strong> " . nl2br(htmlspecialchars($row['message'])) . "</p>";
                echo "</div>";
            }
        } else {
            echo "<p style='color:white; font-size:20px;'>No messages found.</p>";
        }

        $conn->close();
        ?>
    </div>

</body>
</html>
