<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "cafe_app");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ✅ Create table if it doesn't exist (once)
$createTableSQL = "
CREATE TABLE IF NOT EXISTS customer_reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    product VARCHAR(100),
    review TEXT,
    feedback TEXT,
    rating INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($createTableSQL);

// ✅ Ensure 'rating' column exists (safe to run each time)
$checkColumnSQL = "SHOW COLUMNS FROM customer_reviews LIKE 'rating'";
$result = $conn->query($checkColumnSQL);
if ($result->num_rows === 0) {
    $alterTableSQL = "ALTER TABLE customer_reviews ADD rating INT";
    $conn->query($alterTableSQL);
}

// ✅ Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Sanitize inputs
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $product = trim($_POST['product']);
    $review = trim($_POST['review']);
    $feedback = trim($_POST['feedback']);
    $rating = intval($_POST['rating']);

    // Optional: Validate rating is 1 to 5
    if ($rating < 1 || $rating > 5) {
        $rating = 5; // default
    }

    // ✅ Insert using prepared statements for security
    $stmt = $conn->prepare("INSERT INTO customer_reviews (name, email, product, review, feedback, rating) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssi", $name, $email, $product, $review, $feedback, $rating);

    if ($stmt->execute()) {
        echo "<script>alert('Thank you for your review!'); window.location.href='review.html';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
