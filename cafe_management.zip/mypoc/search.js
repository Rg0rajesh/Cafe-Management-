function searchProducts() {
    const query = document.getElementById("searchBar").value.trim();
    const resultsDiv = document.getElementById("searchResults");

    if (query.length === 0) {
        resultsDiv.innerHTML = "";
        resultsDiv.style.display = "none";
        return;
    }

    fetch(`search_backend.php?q=${encodeURIComponent(query)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error("Network error");
            }
            return response.json();
        })
        .then(data => {
            resultsDiv.innerHTML = "";

            if (data.length === 0) {
                resultsDiv.innerHTML = "<div class='no-results'>No items found.</div>";
                resultsDiv.style.display = "block";
                return;
            }

            data.forEach(item => {
                const div = document.createElement("div");
                div.className = "result-item";
                div.innerHTML = `
                    <img src="uploads/${item.image_path}" alt="${item.name}" onerror="this.src='uploads/placeholder.jpg'">
                    <p><span>${item.name}</span> - ${item.category} (₹${item.price})</p>
                `;
                div.onclick = () => {
                    window.location.href = `${item.redirect_page}?item=${encodeURIComponent(item.name)}`;
                };
                resultsDiv.appendChild(div);
            });
            resultsDiv.style.display = "block";
        })
        .catch(error => {
            console.error("Search error:", error);
            resultsDiv.innerHTML = "<div class='error'>Error loading results.</div>";
            resultsDiv.style.display = "block";
        });
}

// Hide search results when clicking outside
document.addEventListener("click", function (e) {
    const searchBar = document.getElementById("searchBar");
    const searchResults = document.getElementById("searchResults");
    if (!searchBar.contains(e.target) && !searchResults.contains(e.target)) {
        searchResults.style.display = "none";
    }
});