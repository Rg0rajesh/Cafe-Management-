<?php
header('Content-Type: application/json');
$host = "localhost";
$user = "root";
$pass = "";
$db = "cafe_app";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$date = $_GET['date'];
$result = $conn->query("SELECT * FROM orders WHERE order_date = '$date'");

$orders = [];
while ($row = $result->fetch_assoc()) {
    $order_id = $row['id'];
    $itemsRes = $conn->query("SELECT * FROM order_items WHERE order_id = $order_id");
    $items = [];
    while ($itemRow = $itemsRes->fetch_assoc()) {
        $items[$itemRow['item_name']] = [
            "price" => $itemRow['price'],
            "quantity" => $itemRow['quantity']
        ];
    }

    $row['items'] = $items;
    $orders[] = $row;
}

echo json_encode($orders);
$conn->close();
?>
