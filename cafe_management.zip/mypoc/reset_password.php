<?php
header("Content-Type: application/json");

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cafe_app";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed."]);
    exit();
}

// Get input data
$input = json_decode(file_get_contents("php://input"), true);
$identifier = trim($input['identifier']);
$newPassword = $input['newPassword'];

// Validate identifier
$emailRegex = "/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/";
$phoneRegex = "/^[6-9]\d{9}$/";
$isEmail = preg_match($emailRegex, $identifier);
$isPhone = preg_match($phoneRegex, $identifier);

if (!$isEmail && !$isPhone) {
    echo json_encode(["success" => false, "message" => "Invalid email or phone number."]);
    exit();
}

// Validate password
if (!preg_match("/^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#]).{8,}$/", $newPassword)) {
    echo json_encode(["success" => false, "message" => "Password must be at least 8 characters, contain an uppercase letter, a number, and a special character."]);
    exit();
}

// Check if identifier exists
$field = $isEmail ? "email" : "phone";
$stmt = $conn->prepare("SELECT id FROM cafe_users WHERE $field = ?");
$stmt->bind_param("s", $identifier);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "No account found with this " . ($isEmail ? "email" : "phone number") . "."]);
    exit();
}
$stmt->close();

// Hash new password
$passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);

// Update password
$stmt = $conn->prepare("UPDATE cafe_users SET password_hash = ? WHERE $field = ?");
$stmt->bind_param("ss", $passwordHash, $identifier);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to reset password."]);
}

$stmt->close();
$conn->close();
?>