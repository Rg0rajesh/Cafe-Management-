<?php
header('Content-Type: application/json');
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cafe_app";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => "Connection failed: " . $e->getMessage()]);
    exit;
}

$input = file_get_contents('php://input');
$order = json_decode($input, true);

if (!$order) {
    echo json_encode(['success' => false, 'message' => "Invalid order data"]);
    exit;
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => "Please log in to place an order"]);
    exit;
}

// Fetch phone from cafe_users
$phone_number = null;
try {
    $stmt = $conn->prepare("SELECT phone FROM cafe_users WHERE id = :user_id");
    $stmt->execute(['user_id' => $_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user && $user['phone']) {
        $phone_number = $user['phone'];
        // Validate phone (10-15 digits, per VARCHAR(15))
        if (!preg_match('/^\d{10,15}$/', $phone_number)) {
            echo json_encode(['success' => false, 'message' => "Invalid phone number format in your account. Please update your profile."]);
            exit;
        }
    } else {
        echo json_encode(['success' => false, 'message' => "Phone number not found. Please update your profile."]);
        exit;
    }
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => "Error fetching phone number: " . $e->getMessage()]);
    exit;
}

$customer_id = $order['customerID'];
$customer_name = $order['customerName'];
$items = json_encode($order['items']);
$total = $order['total'];
$state_tax = $order['stateTax'];
$central_tax = $order['centralTax'];
$total_tax = $order['totalTax'];
$date = $order['date'];
$time = $order['time'];
$num_persons = $order['numPersons'];
$table_number = $order['tableNumber'];

$employee_id = null;
try {
    $stmt = $conn->query("SELECT id FROM employees WHERE role = 'server' ORDER BY RAND() LIMIT 1");
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($employee) {
        $employee_id = $employee['id'];
    }
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => "Error fetching server: " . $e->getMessage()]);
    exit;
}

try {
    $stmt = $conn->prepare("
        INSERT INTO orders (customer_id, customer_name, phone_number, items, total, state_tax, central_tax, total_tax, date, time, num_persons, table_number, employee_id)
        VALUES (:customer_id, :customer_name, :phone_number, :items, :total, :state_tax, :central_tax, :total_tax, :date, :time, :num_persons, :table_number, :employee_id)
    ");
    $stmt->execute([
        'customer_id' => $customer_id,
        'customer_name' => $customer_name,
        'phone_number' => $phone_number,
        'items' => $items,
        'total' => $total,
        'state_tax' => $state_tax,
        'central_tax' => $central_tax,
        'total_tax' => $total_tax,
        'date' => $date,
        'time' => $time,
        'num_persons' => $num_persons,
        'table_number' => $table_number,
        'employee_id' => $employee_id
    ]);
    echo json_encode(['success' => true]);
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => "Error saving order: " . $e->getMessage()]);
}

$conn = null;
?>