<?php
$conn = new mysqli("localhost", "root", "", "cafe_app");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle aggregate selection
$selectedOption = $_POST['aggregate_option'] ?? '';
$aggregateResult = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['show_aggregate'])) {
    if ($selectedOption === 'average_rating') {
        $q = $conn->query("SELECT ROUND(AVG(rating), 2) AS avg_rating FROM customer_reviews");
        $data = $q->fetch_assoc();
        $aggregateResult = "Average Rating: " . ($data['avg_rating'] ?? 'N/A');
    } elseif ($selectedOption === 'total_reviews') {
        $q = $conn->query("SELECT COUNT(*) AS total_reviews FROM customer_reviews");
        $data = $q->fetch_assoc();
        $aggregateResult = "Total Reviews: " . ($data['total_reviews'] ?? '0');
    } elseif ($selectedOption === 'best_product') {
        $q = $conn->query("SELECT product, ROUND(AVG(rating), 2) AS avg_rating 
                           FROM customer_reviews GROUP BY product 
                           ORDER BY avg_rating DESC LIMIT 1");
        $data = $q->fetch_assoc();
        $aggregateResult = "Best Rated Product: " . ($data['product'] ?? 'N/A') . " (Rating: " . ($data['avg_rating'] ?? '0') . ")";
    }
}

// Fetch reviews
$sql = "
SELECT
  CONCAT(UCASE(LEFT(name, 1)), LCASE(SUBSTRING(name, 2))) AS name,
  email,
  product,
  LCASE(review) AS review,
  feedback,
  rating,
  DATE_FORMAT(created_at, '%d-%m-%Y') AS created_at
FROM customer_reviews
ORDER BY created_at DESC
";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Customer Reviews</title>
    <style>
        body {
            background-color: white;
            font-family: 'Comic Sans MS', cursive, sans-serif;
            text-align: center;
        }
        h1 {
            color: #00e600;
            font-size: 50px;
            text-shadow: 3px 3px #a6f;
        }
        .review-box {
            width: 80%;
            margin: 20px auto;
            background-color: white;
            border: 10px solid #9356f1;
            border-radius: 30px;
            padding: 20px;
            text-align: left;
        }
        .review-entry {
            border-bottom: 2px solid #9356f1;
            padding: 15px 0;
        }
        .review-entry:last-child {
            border-bottom: none;
        }
        .label {
            font-weight: bold;
            font-style: italic;
        }
        .home-button {
            position: absolute;
            right: 30px;
            top: 30px;
            padding: 10px 20px;
            background-color: orange;
            color: black;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        .home-button:hover {
            background-color: darkorange;
        }
        .aggregate-form {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            border: 5px dashed #9356f1;
            border-radius: 20px;
            background-color: #fdfdfd;
        }
        .aggregate-form select,
        .aggregate-form input[type="submit"] {
            padding: 10px;
            font-family: 'Comic Sans MS', cursive, sans-serif;
            font-size: 16px;
            margin: 10px 0;
        }
        .aggregate-form input[type="submit"] {
            background-color: #9356f1;
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
        }
        .aggregate-form input[type="submit"]:hover {
            background-color: #7b43c5;
        }
    </style>
</head>
<body>
    <h1>REVIEW BY CUSTOMER</h1>
    <a href="admin.html"><button class="home-button">HOME</button></a>

    <!-- ✅ Aggregate Selection -->
    <div class="aggregate-form">
        <form method="POST">
            <label><span class="label">Select a Statistic:</span></label>
            <select name="aggregate_option" required>
                <option value="">-- Choose --</option>
                <option value="average_rating" <?= $selectedOption == 'average_rating' ? 'selected' : '' ?>>Average Rating</option>
                <option value="total_reviews" <?= $selectedOption == 'total_reviews' ? 'selected' : '' ?>>Total Reviews</option>
                <option value="best_product" <?= $selectedOption == 'best_product' ? 'selected' : '' ?>>Best Rated Product</option>
            </select>
            <input type="submit" name="show_aggregate" value="Show">
        </form>

        <?php if (!empty($aggregateResult)): ?>
            <p style="font-weight:bold; font-size: 18px; color: green;"><?= $aggregateResult ?></p>
        <?php endif; ?>
    </div>

    <!-- ✅ Review Display -->
    <div class="review-box">
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <div class="review-entry">
                    <p><span class="label">Name:</span> <?= htmlspecialchars($row['name']) ?></p>
                    <p><span class="label">Email:</span> <?= htmlspecialchars($row['email']) ?></p>
                    <p><span class="label">Product:</span> <?= htmlspecialchars($row['product']) ?></p>
                    <p><span class="label">Review:</span> <?= htmlspecialchars($row['review']) ?></p>
                    <p><span class="label">Feedback:</span> <?= htmlspecialchars($row['feedback']) ?></p>
                    <p><span class="label">Rating:</span>
                        <?php
                        for ($i = 1; $i <= 5; $i++) {
                            echo $i <= $row['rating'] ? "★" : "☆";
                        }
                        ?>
                    </p>
                    <p><span class="label">Submitted On:</span> <?= $row['created_at'] ?></p>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No reviews yet.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php $conn->close(); ?>
