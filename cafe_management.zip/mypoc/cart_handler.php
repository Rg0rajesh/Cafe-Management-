<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $itemName = $_POST["name"];
    $price = floatval($_POST["price"]);
    $image = $_POST["image"];

    if (!isset($_SESSION["cart"])) {
        $_SESSION["cart"] = [];
    }

    if (isset($_SESSION["cart"][$itemName])) {
        $_SESSION["cart"][$itemName]["quantity"] += 1;
    } else {
        $_SESSION["cart"][$itemName] = [
            "price" => $price,
            "image" => $image,
            "quantity" => 1
        ];
    }

    header("Location: mycart.php"); // Redirect to cart
    exit;
}
?>
