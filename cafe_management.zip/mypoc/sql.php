<?php
// sql.php

$servername = "localhost";
$username = "root"; // Change to your DB username
$password = "";     // Change to your DB password
$dbname = "cafe_app"; // Change to your DB name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create employees table
$createEmployeesTable = "CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(100) NOT NULL
)";

if ($conn->query($createEmployeesTable) === TRUE) {
    echo "Employees table created successfully.<br>";
} else {
    echo "Error creating employees table: " . $conn->error . "<br>";
}

// Create orders table
$createOrdersTable = "CREATE TABLE IF NOT EXISTS orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id VARCHAR(10) NOT NULL,
    customer_name VARCHAR(100) NOT NULL,
    items TEXT NOT NULL,
    total DECIMAL(10, 2) NOT NULL,
    state_tax DECIMAL(10, 2) NOT NULL,
    central_tax DECIMAL(10, 2) NOT NULL,
    total_tax DECIMAL(10, 2) NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    num_persons INT NOT NULL,
    table_number VARCHAR(10) NOT NULL,
    employee_id INT,
    FOREIGN KEY (employee_id) REFERENCES employees(id)
)";

if ($conn->query($createOrdersTable) === TRUE) {
    echo "Orders table created successfully.";
} else {
    echo "Error creating orders table: " . $conn->error;
}

$conn->close();
?>
