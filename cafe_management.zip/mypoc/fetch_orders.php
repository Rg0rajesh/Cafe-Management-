<?php
require 'upload_item.php'; // Your DB connection file

$orders_res = $conn->query("SELECT * FROM orders ORDER BY id DESC");
$orders = [];

while ($order = $orders_res->fetch_assoc()) {
    $order_id = $order['id'];
    $items_res = $conn->query("SELECT item_name, price, quantity FROM order_items WHERE order_id = $order_id");
    $items = [];

    while ($item = $items_res->fetch_assoc()) {
        $items[] = $item;
    }

    $order['items'] = $items;
    $orders[] = $order;
}

header('Content-Type: application/json');
echo json_encode($orders);
?>
