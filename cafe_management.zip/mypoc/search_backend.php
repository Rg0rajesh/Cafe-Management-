<?php
header('Content-Type: application/json');

$conn = new mysqli("localhost", "root", "", "cafe_app");
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode([]);
    exit;
}

$q = isset($_GET['q']) ? $conn->real_escape_string($_GET['q']) : '';

$items = [];
if (!empty($q)) {
    $sql = "SELECT item_name, price, category, image_path 
            FROM menu_items 
            WHERE item_name LIKE ? OR category LIKE ? 
            LIMIT 10";
    
    $stmt = $conn->prepare($sql);
    $likeQuery = "%$q%";
    $stmt->bind_param("ss", $likeQuery, $likeQuery);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $category = strtolower($row['category']);
        $redirect_page = "#"; // Default fallback

        // Map categories to pages
        switch ($category) {
            case "food":
                $redirect_page = "food.php";
                break;
            case "desserts":
                $redirect_page = "desserts.php";
                break;
            case "coffee":
                $redirect_page = "coffee.php";
                break;
            case "shakes":
                $redirect_page = "shakes.php";
                break;
        }

        $items[] = [
            'name' => $row['item_name'],
            'price' => $row['price'],
            'category' => $row['category'],
            'image_path' => $row['image_path'],
            'redirect_page' => $redirect_page
        ];
    }

    $stmt->close();
}

echo json_encode($items);
$conn->close();
?>