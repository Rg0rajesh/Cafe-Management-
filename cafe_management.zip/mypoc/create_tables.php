<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "cafe_app"; // replace with your actual database name

$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create orders table
$ordersTable = "
CREATE TABLE IF NOT EXISTS orders (
    orderID INT AUTO_INCREMENT PRIMARY KEY,
    customerName VARCHAR(100),
    date DATE,
    time TIME,
    numPersons INT,
    tableNumber INT,
    stateTax FLOAT,
    centralTax FLOAT,
    totalTax FLOAT,
    total FLOAT,
    employeeID INT
);

";

// Create order_items table
$orderItemsTable = "
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    orderID INT,
    itemName VARCHAR(100),
    quantity INT,
    price DOUBLE,
    FOREIGN KEY (orderID) REFERENCES orders(id) ON DELETE CASCADE
);
";

// Run the queries
if ($conn->query($ordersTable) === TRUE) {
    echo "Table 'orders' created successfully.<br>";
} else {
    echo "Error creating 'orders' table: " . $conn->error . "<br>";
}

if ($conn->query($orderItemsTable) === TRUE) {
    echo "Table 'order_items' created successfully.<br>";
} else {
    echo "Error creating 'order_items' table: " . $conn->error . "<br>";
}

$conn->close();
?>
