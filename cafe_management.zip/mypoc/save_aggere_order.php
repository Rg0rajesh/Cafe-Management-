<?php
header('Content-Type: application/json');

// 1. Get JSON input
$data = json_decode(file_get_contents('php://input'), true);

// 2. Check required fields
$required = ['customerName', 'tableNumber', 'date', 'time', 'items', 'stateTax', 'centralTax', 'totalTax', 'total'];
foreach ($required as $field) {
    if (!isset($data[$field]) || $data[$field] === "") {
        echo json_encode(["status" => "error", "message" => "Missing field: $field"]);
        exit;
    }
}

// 3. DB connection
$conn = new mysqli("localhost", "root", "Rajesh09#", "cafe_app");
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "DB connection failed: " . $conn->connect_error]);
    exit;
}

// ✅ 4. Create tables if they don't exist
$createOrdersTable = "
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(255),
    table_number VARCHAR(20),
    date DATE,
    time TIME,
    state_tax DOUBLE,
    central_tax DOUBLE,
    total_tax DOUBLE,
    total DOUBLE,
    employee_id INT,
    employee_role VARCHAR(100)
)";

$createOrderItemsTable = "
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    item_name VARCHAR(255),
    price DOUBLE,
    quantity INT,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
)";

if (!$conn->query($createOrdersTable)) {
    echo json_encode(["status" => "error", "message" => "Failed to create 'orders' table: " . $conn->error]);
    exit;
}

if (!$conn->query($createOrderItemsTable)) {
    echo json_encode(["status" => "error", "message" => "Failed to create 'order_items' table: " . $conn->error]);
    exit;
}

// 5. Pick random employee
$empResult = $conn->query("SELECT id, role FROM employees ORDER BY RAND() LIMIT 1");
if ($empResult && $empResult->num_rows > 0) {
    $employee = $empResult->fetch_assoc();
    $employeeID = $employee['id'];
    $employeeRole = $employee['role'];
} else {
    $employeeID = null;
    $employeeRole = null;
}

// 6. Insert order
$stmt = $conn->prepare("INSERT INTO orders 
    (customer_name, table_number, date, time, state_tax, central_tax, total_tax, total, employee_id, employee_role) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
);
if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Prepare failed: " . $conn->error]);
    exit;
}

$stmt->bind_param(
    "ssssddddis",
    $data['customerName'],
    $data['tableNumber'],
    $data['date'],
    $data['time'],
    floatval($data['stateTax']),
    floatval($data['centralTax']),
    floatval($data['totalTax']),
    floatval($data['total']),
    $employeeID,
    $employeeRole
);

if ($stmt->execute()) {
    $orderID = $stmt->insert_id;

    // 7. Insert each item
    $itemStmt = $conn->prepare("INSERT INTO order_items (order_id, item_name, price, quantity) VALUES (?, ?, ?, ?)");
    if (!$itemStmt) {
        echo json_encode(["status" => "error", "message" => "Item prepare failed: " . $conn->error]);
        exit;
    }

    foreach ($data['items'] as $item) {
        $itemStmt->bind_param("isdi", $orderID, $item['itemName'], $item['price'], $item['quantity']);
        $itemStmt->execute();
    }

    echo json_encode(["status" => "success", "orderID" => $orderID]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to insert order: " . $stmt->error]);
}

$conn->close();
?>
