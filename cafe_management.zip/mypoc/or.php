<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cafe_app";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Initialize date filter variables
$start_date = isset($_GET['start_date']) && !empty($_GET['start_date']) ? $_GET['start_date'] : '';
$end_date = isset($_GET['end_date']) && !empty($_GET['end_date']) ? $_GET['end_date'] : '';

// Validate date range
if ($start_date && $end_date && strtotime($start_date) > strtotime($end_date)) {
    die("Error: Start date cannot be later than end date.");
}

// Fetch all orders with assigned server using a JOIN
try {
    $sql = "
        SELECT o.*, e.name AS server_name
        FROM orders o
        LEFT JOIN employees e ON o.employee_id = e.id
    ";
    $params = [];
    if ($start_date && $end_date) {
        $sql .= " WHERE o.date BETWEEN :start_date AND :end_date";
        $params[':start_date'] = $start_date;
        $params[':end_date'] = $end_date;
    }
    $sql .= " ORDER BY CONCAT(o.date, ' ', o.time) DESC";
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Error fetching orders: " . $e->getMessage());
}

$conn = null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Received</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: white;
            margin: 0;
            padding: 0;
        }
        .container {
            text-align: center;
            padding: 20px;
        }
        .title {
            font-size: 40px;
            font-weight: bold;
            color: orange;
        }
        .content-box {
            width: 80%;
            margin: 20px auto;
            background: #D19BF5;
            padding: 50px;
            border-radius: 15px;
        }
        .sidebar {
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .sidebar .admin {
            color: orange;
            font-weight: bold;
        }
        #orders {
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 20px;
        }
        .order-item {
            background: #D19BF5;
            padding: 30px;
            margin: 30px auto;
            border-radius: 20px;
            width: 80%;
            max-width: 800px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            text-align: left;
            color: #333;
        }
        .order-item h3, .order-item h4 {
            color: #6A0DAD;
        }
        .order-item img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            margin-right: 10px;
            border-radius: 5px;
            vertical-align: middle;
        }
        .order-item button {
            background-color: #6A0DAD;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 8px;
            cursor: pointer;
        }
        .order-item button:hover {
            background-color: #4B0082;
        }
        .date-filter {
            margin-bottom: 20px;
        }
        .date-filter input {
            padding: 5px;
            margin-right: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .date-filter button {
            background-color: #6A0DAD;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
        }
        .date-filter button:hover {
            background-color: #4B0082;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="title">ORDERS RECEIVED</div>
        
        <div class="sidebar">
            <button style="background-color:blueviolet; border:none;">
                <p class="admin"><a href="admin.html" style="text-decoration:none; color:orange;">HOME</a></p>
            </button>
        </div>

        <div id="orders">
            <h2>Admin Orders</h2>
            <!-- Date Filter Form -->
            <div class="date-filter">
                <form method="GET" action="">
                    <label for="start_date">Start Date:</label>
                    <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>">
                    <label for="end_date">End Date:</label>
                    <input type="date" id="end_date" name="end_date" value=

<?php echo htmlspecialchars($end_date); ?>">
                    <button type="submit">Filter</button>
                </form>
            </div>
            <?php if (empty($orders)): ?>
                <p>No orders found.</p>
            <?php else: ?>
                <?php foreach ($orders as $order): ?>
                    <?php 
                    $items = json_decode($order['items'], true);
                    if (!is_array($items)) {
                        $items = []; // Fallback to empty array if JSON decode fails
                    }
                    ?>
                    <div class="order-item">
                        <h3>Order ID: <?php echo htmlspecialchars($order['customer_id']); ?></h3>
                        <p><strong>GST No:</strong> GS9945AP65GNT9</p>
                        <p><strong>Customer Name:</strong> <?php echo htmlspecialchars($order['customer_name']); ?></p>
                        <p><strong>Phone Number:</strong> <?php echo htmlspecialchars($order['phone_number']); ?></p>
                        <p><strong>Date:</strong> <?php echo htmlspecialchars($order['date']); ?> at <?php echo htmlspecialchars($order['time']); ?></p>
                        <p><strong>Number of Persons:</strong> <?php echo htmlspecialchars($order['num_persons']); ?></p>
                        <p><strong>Table Number:</strong> <?php echo htmlspecialchars($order['table_number']); ?></p>
                        <p><strong>Assigned Server:</strong> <?php echo htmlspecialchars($order['server_name'] ?? 'Not assigned'); ?></p>
                        <h4>Items:</h4>
                        <?php if (!empty($items)): ?>
                            <ul>
                                <?php foreach ($items as $item): ?>
                                    <?php 
                                    $item_name = $item['name'] ?? 'Unknown';
                                    $subtotal = ($item['price'] ?? 0) * ($item['quantity'] ?? 0); 
                                    ?>
                                    <li>
                                        <img src="<?php echo htmlspecialchars($item['image'] ?? 'placeholder.jpg'); ?>" alt="<?php echo htmlspecialchars($item_name); ?>">
                                        <strong><?php echo htmlspecialchars($item_name); ?></strong> -
                                        ₹<?php echo number_format($item['price'] ?? 0, 2); ?> x <?php echo ($item['quantity'] ?? 0); ?> =
                                        ₹<?php echo number_format($subtotal, 2); ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php else: ?>
                            <p>No items found for this order.</p>
                        <?php endif; ?>
                        <p><strong>State Tax (5%):</strong> ₹<?php echo number_format($order['state_tax'] ?? 0, 2); ?></p>
                        <p><strong>Central Tax (10%):</strong> ₹<?php echo number_format($order['central_tax'] ?? 0, 2); ?></p>
                        <p><strong>Total Tax:</strong> ₹<?php echo number_format($order['total_tax'] ?? 0, 2); ?></p>
                        <p><strong>Grand Total:</strong> ₹<?php echo number_format($order['total'] ?? 0, 2); ?></p>
                        <button onclick="printOrder(this)">Print Order</button>
                    </div>
                <?php endforeach; ?>
                <button onclick="window.print()" style="margin: 20px; background-color:#6A0DAD; color:white; padding:10px 20px; border:none; border-radius:10px;">Print All Orders</button>
            <?php endif; ?>
        </div>
    </div>
    <script>
        function printOrder(button) {
            const orderDiv = button.closest('.order-item');
            const printWindow = window.open('', '', 'height=600,width=800');
            printWindow.document.write('<html><head><title>Print Order</title>');
            printWindow.document.write('<style>');
            printWindow.document.write(`
                body { font-family: Arial, sans-serif; padding: 20px; background-color: #D19BF5; }
                .order-item { color: #333; }
                img { width: 50px; height: 50px; object-fit: cover; border-radius: 5px; }
                h3, h4 { color: #6A0DAD; }
            `);
            printWindow.document.write('</style></head><body>');
            printWindow.document.write(orderDiv.innerHTML);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.focus();
            printWindow.print();
            printWindow.close();
        }
    </script>
</body>
</html>