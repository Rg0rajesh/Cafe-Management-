<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'cafe_app';
$conn = new mysqli($host, $user, $pass, $db);

$result = $conn->query("SELECT * FROM menu_items ORDER BY created_at DESC");

$items = [];
while ($row = $result->fetch_assoc()) {
    $items[] = $row;
}
header('Content-Type: application/json');
echo json_encode($items);
?>
