<?php
session_start();
$conn = new mysqli("localhost", "root", "", "cafe_appo");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$user_id = 1;
$employee_sql = "SELECT id FROM employees WHERE role = 'Server' ORDER BY RAND() LIMIT 1";
$employee = $conn->query($employee_sql)->fetch_assoc();

$conn->query("INSERT INTO orders (user_id, employee_id) VALUES ($user_id, {$employee['id']})");
$order_id = $conn->insert_id;

$cart_items = $conn->query("SELECT item_id FROM cart WHERE user_id = $user_id");
while ($item = $cart_items->fetch_assoc()) {
    $conn->query("INSERT INTO order_items (order_id, item_id) VALUES ($order_id, {$item['item_id']})");
}
$conn->query("DELETE FROM cart WHERE user_id = $user_id");

header("Location: orders.html");
?>
