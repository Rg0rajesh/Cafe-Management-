<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

// Debugging: Uncomment to inspect session data
// echo "<pre>";
// print_r($_SESSION['user']);
// echo "</pre>";

if (!isset($_SESSION['user'])) {
    header("Location: login.html");
    exit();
}

$user = $_SESSION['user'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
    <script src="search.js"></script>

    <title>Profile Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding-top: 90px;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #222;
            padding: 30px 40px;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
        }
        .nav-left .search-bar {
            padding: 8px;
            border: none;
            border-radius: 5px;
            width: 200px;
        }
        .nav-center {
            display: flex;
            align-items: center;
            flex-grow: 1;
            justify-content: center;
            position: relative;
        }
        .nav-center .nav-links {
            list-style: none;
            display: flex;
            align-items: center;
        }
        .nav-center .nav-links li {
            margin: 0 15px;
        }
        .nav-center .nav-links a {
            text-decoration: none;
            color: white;
            font-size: 16px;
            transition: 0.3s;
        }
        .nav-center .nav-links a:hover {
            color: #f4a700;
        }
        .logo {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            top: -12px;
            z-index: 1000;
            width: 100px;
            height: 100px;
            background-color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            padding: 5px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }
        .logo img {
            width: 90%;
            height: auto;
            object-fit: contain;
        }
        .nav-center .nav-links:first-child {
            margin-right: 160px;
        }
        .nav-center .nav-links:last-child {
            margin-left: 160px;
        }
        .nav-right {
            display: flex;
            align-items: center;
        }
        .nav-right .login {
            color: white;
            text-decoration: none;
            margin-right: 15px;
            font-size: 16px;
        }
        .nav-right .cart-icon {
            font-size: 20px;
            color: white;
            text-decoration: none;
        }
        .nav-right a:hover {
            color: #f4a700;
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #222;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
            border-radius: 5px;
        }
        .dropdown-content a {
            color: white;
            padding: 12px 16px;
            display: block;
            text-decoration: none;
            transition: 0.3s;
        }
        .dropdown-content a:hover {
            background-color: #444;
            color: #f4a700;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
        .search-bar {
            width: 100%;
            max-width: 250px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin: 5px 0;
        }
        .search-results {
            max-width: 250px;
            border: 1px solid #ddd;
            border-radius: 5px;
            max-height: 300px;
            overflow-y: auto;
            background: #fff;
            position: absolute;
            z-index: 1000;
            display: none;
            top: 100%;
            left: 25px;
        }
        .search-results .result-item {
            display: flex;
            align-items: center;
            padding: 10px;
            cursor: pointer;
            border-bottom: 1px solid #eee;
        }
        .search-results .result-item:hover {
            background: #f5f5f5;
        }
        .search-results .result-item img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            margin-right: 10px;
            border-radius: 5px;
        }
        .search-results .result-item p {
            margin: 0;
            font-size: 14px;
        }
        .search-results .result-item p span {
            font-weight: bold;
        }
        .search-results .no-results, .search-results .error {
            padding: 10px;
            font-size: 14px;
        }
        .search-results .error {
            color: red;
        }
        .profile-container {
            max-width: 900px;
            margin: 100px auto 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .profile-header {
            display: flex;
            align-items: center;
            background: #fff;
            padding: 20px;
            border-bottom: 2px solid #eaeaea;
            position: relative;
        }
        .profile-pic {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-right: 20px;
            object-fit: cover;
            border: 2px solid #f4a700;
        }
        .profile-header h2 {
            color: #0275d8;
            margin-bottom: 5px;
        }
        .profile-header p {
            color: gray;
            font-size: 14px;
        }
        .edit-button {
            background-color: #0275d8;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            position: absolute;
            right: 20px;
            top: 20px;
        }
        .edit-button:hover {
            background-color: #025aa5;
        }
        .profile-section {
            padding: 20px;
            display: none;
        }
        .profile-section.active {
            display: block;
        }
        .profile-section h3 {
            border-bottom: 2px solid #f4a700;
            padding-bottom: 5px;
            margin-bottom: 20px;
        }
        .profile-form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .profile-form label {
            font-weight: bold;
            margin-bottom: 5px;
        }
        .profile-form input,
        .profile-form textarea {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }
        .profile-form input[type="file"] {
            padding: 3px;
        }
        .profile-form button {
            background-color: #f4a700;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .profile-form button:hover {
            background-color: #d48c00;
        }
        .error-message {
            color: red;
            font-size: 12px;
            margin-top: 5px;
        }
        .logout-button {
            background-color: #dc3545;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            position: absolute;
            right: 20px;
            top: 60px;
            display: inline-block;
            transition: background-color 0.3s;
        }
        .logout-button:hover {
            background-color: #c82333;
        }
        .welcome-message {
            text-align: center;
            padding: 20px 0;
            background: #f4a700;
            color: white;
            border-radius: 10px 10px 0 0;
        }
        .welcome-message h1 {
            font-size: 24px;
            margin: 0;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-left">
            <a>🔎</a>
            <input type="text" id="searchBar" placeholder="Search products..." class="search-bar" onkeyup="searchProducts()">
            <div id="searchResults" class="search-results"></div>
        </div>
        <div class="nav-center">
            <ul class="nav-links">
                <li><a href="home.html">Home</a></li>
                <li><a href="about us.html">About Us</a></li>
                <li><a href="story.html">Story</a></li>
            </ul>
            <div class="logo">
                <img src="Heart strings.png" alt="Cafe Niloufer">
            </div>
            <ul class="nav-links">
                <li><a href="orders.html">Orders</a></li>
                <li class="dropdown">
                    <a href="#">Shop Now</a>
                    <div class="dropdown-content">
                        <a href="coffee.php">Coffee</a>
                        <a href="shakes.php">Shakes</a>
                        <a href="food.php">Food</a>
                        <a href="desserts.php">Desserts</a>
                    </div>
                </li>
                <li class="dropdown">
                    <a href="#">Reach Us</a>
                    <div class="dropdown-content">
                        <a href="faq.html">FAQs</a>
                        <a href="contactus.html">Contact Us</a>
                        <a href="review.html">Review</a>
                    </div>
        </div>
        <div class="nav-right">
            <a href="login.html" class="login">Login / Register</a>
            <a href="mycart.html" class="cart-icon">🛒</a>
            <a href="profile.php">
                <i class="fa-solid fa-circle-user fa-lg" style="color: #ffffff;"></i>
            </a>
        </div>
    </nav>

    <div class="profile-container">
        <div class="welcome-message">
            <h1>Welcome!, <?php echo htmlspecialchars(ucfirst($user['first_name']) . ' ' . ucfirst($user['last_name'])); ?></h1>
        </div>
        <div class="profile-header">
            <img id="profilePic" src="<?php echo htmlspecialchars($user['profile_image'] ?? 'images/default-profile.jpg'); ?>" alt="Profile Picture" class="profile-pic">
            <div>
                <h2 id="userName"><?php echo htmlspecialchars(ucfirst($user['first_name']) . ' ' . ucfirst($user['last_name'])); ?></h2>
                <p id="userEmail"><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                <p id="userPhone"><strong>Phone:</strong> <?php echo htmlspecialchars($user['phone'] ?? 'Not provided'); ?></p>
                <p id="userAddress"><strong>Address:</strong> 
                    <?php 
                    $address = [];
                    if (!empty($user['area'])) $address[] = htmlspecialchars($user['area']);
                    if (!empty($user['city'])) $address[] = htmlspecialchars($user['city']);
                    if (!empty($user['state'])) $address[] = htmlspecialchars($user['state']);
                    if (!empty($user['country'])) $address[] = htmlspecialchars($user['country']);
                    if (!empty($user['pincode'])) $address[] = htmlspecialchars($user['pincode']);
                    echo !empty($address) ? implode(', ', $address) : 'Not provided';
                    ?>
                </p>
            </div>
            <button class="edit-button" onclick="toggleEditForm()">Edit Address & Image</button>
            <a href="logout.php" class="logout-button">Logout</a>
        </div>
        <div class="profile-section" id="editForm">
            <h3>Update Address & Profile Image</h3>
            <form id="profileForm" class="profile-form" enctype="multipart/form-data">
                <label for="profileImage">Profile Image</label>
                <input type="file" id="profileImage" name="profile_image" accept="image/jpeg,image/png,image/gif">
                <div id="imageError" class="error-message"></div>

                <label for="country">Country</label>
                <input type="text" id="country" name="country" placeholder="Enter your country" value="<?php echo htmlspecialchars($user['country'] ?? ''); ?>">

                <label for="state">State</label>
                <input type="text" id="state" name="state" placeholder="Enter your state" value="<?php echo htmlspecialchars($user['state'] ?? ''); ?>">

                <label for="district">District</label>
                <input type="text" id="district" name="city" placeholder="Enter your district" value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>">

                <label for="area">Area</label>
                <textarea id="area" name="area" placeholder="Enter your area"><?php echo htmlspecialchars($user['area'] ?? ''); ?></textarea>

                <label for="pincode">Pincode</label>
                <input type="text" id="pincode" name="pincode" placeholder="Enter your pincode" value="<?php echo htmlspecialchars($user['pincode'] ?? ''); ?>">

                <button type="submit">Save Changes</button>
            </form>
        </div>
    </div>

    <script>
        // Toggle edit form visibility
        function toggleEditForm() {
            const form = document.getElementById("editForm");
            form.classList.toggle("active");
        }

        // Preview profile image before upload
        document.getElementById("profileImage").addEventListener("change", function (e) {
            const file = e.target.files[0];
            if (file) {
                const validImageTypes = ["image/jpeg", "image/png", "image/gif"];
                if (!validImageTypes.includes(file.type)) {
                    document.getElementById("imageError").innerText = "Please upload a valid image (JPEG, PNG, or GIF).";
                    return;
                }
                const reader = new FileReader();
                reader.onload = function (e) {
                    document.getElementById("profilePic").src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });

        // Handle form submission
        document.getElementById("profileForm").addEventListener("submit", function (e) {
            e.preventDefault();

            const formData = new FormData(this);
            const imageError = document.getElementById("imageError");

            fetch("update_profile.php", {
                method: "POST",
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(`HTTP error! Status: ${response.status}, Response: ${text}`);
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    alert("Address and image updated successfully!");
                    window.location.reload();
                } else {
                    imageError.innerText = data.message || "Failed to update.";
                }
            })
            .catch(error => {
                console.error("Submission error:", error);
                imageError.innerText = "Error: " + error.message;
            });
        });
    </script>
</body>
</html>