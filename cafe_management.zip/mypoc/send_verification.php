<?php
header("Content-Type: application/json");
session_start();

// Database config
$host = "localhost";
$dbname = "cafe_app";
$username = "root";
$password = ""; // Update if your DB has a password

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed."]);
    exit();
}

// Get identifier from POST
$input = json_decode(file_get_contents("php://input"), true);
$identifier = trim($input['identifier']);

// Validate identifier
$emailRegex = "/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/";
$phoneRegex = "/^[6-9]\d{9}$/";
$isEmail = preg_match($emailRegex, $identifier);
$isPhone = preg_match($phoneRegex, $identifier);

if (!$isEmail && !$isPhone) {
    echo json_encode(["success" => false, "message" => "Invalid email or phone number."]);
    exit();
}

// Check if identifier exists
$field = $isEmail ? "email" : "phone";
$query = $conn->prepare("SELECT id FROM cafe_users WHERE $field = ?");
$query->bind_param("s", $identifier);
$query->execute();
$query->store_result();

if ($query->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "No account found with this " . ($isEmail ? "email" : "phone number") . "."]);
    exit();
}
$query->close();

// Generate a 6-digit verification code
$verificationCode = sprintf("%06d", mt_rand(0, 999999));

// Store verification code in session (or database for production)
$_SESSION['verification_code'] = $verificationCode;
$_SESSION['identifier'] = $identifier;

// For simplicity, we'll assume email/SMS is sent (implement actual email/SMS service in production)
$sent = true; // Replace with actual email/SMS sending logic, e.g., using PHPMailer or Twilio
if ($sent) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to send verification code."]);
}

$conn->close();
?>