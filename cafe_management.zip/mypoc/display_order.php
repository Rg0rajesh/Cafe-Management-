<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cafe_app";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Helper function to check if a column exists
function getTableColumns($conn, $tableName) {
    $columns = [];
    $res = $conn->query("SHOW COLUMNS FROM $tableName");
    while ($row = $res->fetch_assoc()) {
        $columns[] = $row['Field'];
    }
    return $columns;
}

$orderCols = getTableColumns($conn, 'orders');
$employeeCols = getTableColumns($conn, 'employees');
$itemCols = getTableColumns($conn, 'order_items');

// Determine columns
$employeeIdCol = in_array('emp_id', $employeeCols) ? 'emp_id' : (in_array('id', $employeeCols) ? 'id' : null);
$employeeRoleCol = in_array('role', $employeeCols) ? 'role' : null;

$fields = [
    'o.id AS order_id'
];
if (in_array('customer_name', $orderCols)) $fields[] = 'o.customer_name';
if (in_array('customer_id', $orderCols)) $fields[] = 'o.customer_id';
if ($employeeIdCol) $fields[] = "e.$employeeIdCol AS employee_id";
if ($employeeRoleCol) $fields[] = "e.$employeeRoleCol AS employee_role";
if (in_array('item_name', $itemCols)) $fields[] = 'i.item_name';
if (in_array('item_price', $itemCols)) $fields[] = 'i.item_price';
if (in_array('quantity', $itemCols)) $fields[] = 'i.quantity';

$sql = "
    SELECT " . implode(", ", $fields) . "
    FROM orders o
    LEFT JOIN employees e ON o.employee_id = e.$employeeIdCol
    LEFT JOIN order_items i ON o.id = i.order_id
    ORDER BY o.id DESC
";

$result = $conn->query($sql);

$orders = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $oid = $row['order_id'];

        if (!isset($orders[$oid])) {
            $orders[$oid] = [
                'customer_name' => $row['customer_name'] ?? 'N/A',
                'customer_id' => $row['customer_id'] ?? 'N/A',
                'employee_id' => $row['employee_id'] ?? 'N/A',
                'employee_role' => $row['employee_role'] ?? 'Unknown',
                'items' => []
            ];
        }

        $item = [];
        if (isset($row['item_name'])) $item['item_name'] = $row['item_name'];
        if (isset($row['item_price'])) $item['item_price'] = $row['item_price'];
        if (isset($row['quantity'])) $item['quantity'] = $row['quantity'];

        if (!empty($item)) {
            $orders[$oid]['items'][] = $item;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Display Orders</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #444;
            text-align: center;
        }
        .order {
            background: #fff;
            border: 1px solid #ccc;
            margin-bottom: 20px;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .order h2 {
            margin-top: 0;
        }
        .order-info, .employee-info {
            margin-bottom: 10px;
        }
        table {
            width: 100%;
            margin-top: 10px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #eee;
        }
    </style>
</head>
<body>

<h1>All Orders</h1>

<?php if (!empty($orders)) : ?>
    <?php foreach ($orders as $order_id => $order_data) : ?>
        <div class="order">
            <h2>Order ID: <?= $order_id ?></h2>
            <div class="order-info">
                <strong>Customer Name:</strong> <?= htmlspecialchars($order_data['customer_name']) ?><br>
                <strong>Customer ID:</strong> <?= htmlspecialchars($order_data['customer_id']) ?>
            </div>
            <div class="employee-info">
                <strong>Served By:</strong> Employee ID <?= htmlspecialchars($order_data['employee_id']) ?> 
                (<?= htmlspecialchars($order_data['employee_role']) ?>)
            </div>
            <?php if (!empty($order_data['items'])) : ?>
            <table>
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <?php if (isset($order_data['items'][0]['item_price'])): ?>
                            <th>Item Price (₹)</th>
                        <?php endif; ?>
                        <?php if (isset($order_data['items'][0]['quantity'])): ?>
                            <th>Quantity</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($order_data['items'] as $item) : ?>
                        <tr>
                            <td><?= htmlspecialchars($item['item_name'] ?? '-') ?></td>
                            <?php if (isset($item['item_price'])): ?>
                                <td><?= htmlspecialchars($item['item_price']) ?></td>
                            <?php endif; ?>
                            <?php if (isset($item['quantity'])): ?>
                                <td><?= htmlspecialchars($item['quantity']) ?></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else : ?>
                <p><em>No items found for this order.</em></p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
<?php else : ?>
    <p>No orders found.</p>
<?php endif; ?>

</body>
</html>

<?php $conn->close(); ?>
