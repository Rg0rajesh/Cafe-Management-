<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cafe_app";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if not exists
$conn->query("CREATE DATABASE IF NOT EXISTS $dbname");

// Select the database
$conn->select_db($dbname);

// Create table if not exists
$conn->query("CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(100) NOT NULL
)");

// Set AUTO_INCREMENT starting value to 101
$conn->query("ALTER TABLE employees AUTO_INCREMENT = 101");

// Handle delete request
$message = "";
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['delete_id'])) {
    $delete_id = intval($_POST['delete_id']);
    $stmt = $conn->prepare("DELETE FROM employees WHERE id = ?");
    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        $message = "Employee deleted successfully!";
    } else {
        $message = "Error deleting employee: " . $stmt->error;
    }

    $stmt->close();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['name']) && isset($_POST['role'])) {
    $name = $_POST['name'] ?? '';
    $role = $_POST['role'] ?? '';

    if (!empty($name) && !empty($role)) {
        $stmt = $conn->prepare("INSERT INTO employees (name, role) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $role);

        if ($stmt->execute()) {
            $message = "Employee added successfully!";
        } else {
            $message = "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $message = "Please fill all fields.";
    }
}

// Fetch existing employees
$employees = [];
$result = $conn->query("SELECT * FROM employees");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #ffffff;
        }
        .header {
            font-size: 24px;
            font-weight: bold;
            margin: 20px 0;
        }
        .container {
            background-color: #c267e9;
            padding: 20px;
            border-radius: 10px;
            width: 80%;
            margin: auto;
        }
        .staff-list {
            margin-top: 20px;
            background-color: white;
            padding: 10px;
            border-radius: 10px;
        }
        .staff-entry {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        .btn {
            padding: 10px;
            border: none;
            background-color: #6a0dad;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #5808b8;
        }
        select, input[type="text"], button {
            padding: 8px;
            margin: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .message {
            margin: 10px 0;
            color: green;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="header">Staff & Your Team</div>
    <div class="container">
        <form method="POST">
            <input type="text" name="name" placeholder="Employee Name" required>
            <select name="role" required>
                <option value="">Select Role</option>
                <option value="Chef">Chef</option>
                <option value="Accounter">Accounter</option>
                <option value="Server">Server</option>
            </select>
            <button type="submit" class="btn">Add Employee</button>
        </form>

        <?php if (!empty($message)) echo "<div class='message'>$message</div>"; ?>

        <div class="staff-list" id="staffList">
            <?php foreach ($employees as $staff): ?>
                <div class="staff-entry">
                    <form method="POST" style="display: flex; justify-content: space-between; align-items: center; width: 100%;">
                        <div>
                            <strong><?php echo htmlspecialchars($staff['name']); ?></strong>
                            | Role: <?php echo htmlspecialchars($staff['role']); ?>
                            | ID: EMP_<?php echo $staff['id']; ?>
                        </div>
                        <input type="hidden" name="delete_id" value="<?php echo $staff['id']; ?>">
                        <button type="submit" class="btn" style="background-color: red;">Delete</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
