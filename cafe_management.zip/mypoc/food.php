<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
    <script src="search.js"></script>
    <title>FOOD MENU</title>
    <style>
           /* General Styles */
        /* Hide Scrollbars but Allow Scrolling */
body {
    margin: 0;
    font-family: Arial, sans-serif;
    overflow-x: hidden;
    overflow-y: auto;
    height: 100vh;
}

/* Hide scrollbar for Webkit (Chrome, Safari) */
body::-webkit-scrollbar {
    display: none;
}

/* Hide scrollbar for Firefox */
body {
    scrollbar-width: none;
}

/* Hide scrollbar for the menu section */
.menu-section {
    overflow-y: auto;
}

/* Hide scrollbar for Webkit (Chrome, Safari) */
.menu-section::-webkit-scrollbar {
    display: none;
}

/* Hide scrollbar for Firefox */
.menu-section {
    scrollbar-width: none;
}


* {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #222;
            padding: 30px 40px;
            position: fixed;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
        }


body {
    padding-top: 60px; /* Adjust this based on the navbar height */
}

        .nav-left .search-bar {
            padding: 8px;
            border: none;
            border-radius: 5px;
            width: 200px;
        }

        .nav-center {
            display: flex;
            align-items: center;
            flex-grow: 1;
            justify-content: center;
            position: relative;
        }

        .nav-center .nav-links {
            list-style: none;
            display: flex;
            align-items: center;
        }

        .nav-center .nav-links li {
            margin: 0 15px;
        }

        .nav-center .nav-links a {
            text-decoration: none;
            color: white;
            font-size: 16px;
            transition: 0.3s;
        }

        .nav-center .nav-links a:hover {
            color: #f4a700;
        }

        /* Logo Styling */
        .logo {
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    top: -12px; /* Move the logo slightly higher */
    z-index: 1000;
    
    width: 100px; /* Adjust width to make it a perfect circle */
    height: 100px; /* Equal width and height for a circle */
    background-color: white;
    
    display: flex;
    align-items: center;
    justify-content: center;
    
    border-radius: 50%; /* Makes the shape a perfect circle */
    padding: 5px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2); /* Optional shadow */
    overflow: hidden; /* Ensures image stays inside */
}

/* Ensuring the logo image fits inside the circle properly */
.logo img {
    width: 90%; /* Ensure it fits within the circle */
    height: auto;
    object-fit: contain; /* Prevents distortion */
}


        /* Ensure navigation links are spaced correctly */
        .nav-center .nav-links:first-child {
            margin-right: 160px; /* Space to accommodate logo */
        }

        .nav-center .nav-links:last-child {
            margin-left: 160px; /* Space to accommodate logo */
        }

        .nav-right {
            display: flex;
            align-items: center;
        }

        .nav-right .login {
            color: white;
            text-decoration: none;
            margin-right: 15px;
            font-size: 16px;
        }

        .nav-right .cart-icon {
            font-size: 20px;
            color: white;
            text-decoration: none;
        }

        .nav-right a:hover {
            color: #f4a700;
        }
         /* Dropdown Styling */
    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #222;
        min-width: 160px;
        box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
        z-index: 1;
        border-radius: 5px;
    }

    .dropdown-content a {
        color: white;
        padding: 12px 16px;
        display: block;
        text-decoration: none;
        transition: 0.3s;
    }

    .dropdown-content a:hover {
        background-color: #444;
        color: #f4a700;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

        /* Video Section */
        .video-container {
            position: fixed;
            width: 1920px;
            height: 1080px;
            top: 0;
            left: 0;
            overflow: hidden;
            z-index: -1; /* Keeps video in the background */
            height: 50vh;
            
        }

        .video-container video {
            width: 100%;
            height: 100%;
            object-fit:cover;
        }

        /* Menu Section */
        .menu-section {
            width: 100%;
            background: #f3ead3;
            padding: 40px 0;
            text-align: center;
            min-height: 100vh;
            margin-top: 0; /* No margin at top, allows immediate scroll */
            padding-right: 17px; /* Accommodate hidden scrollbar */
            overflow-y: auto; /* Allow vertical scrolling in menu */
        }


        .menu-title {
            font-size: 30px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        /* Menu Items */
        .menu-items {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
            width: 80%;
            margin: 0 auto;
        }

        .item {
            background: white;
            padding: 15px;
            width: 250px;
            border-radius: 10px;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .item img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 10px;
        }

        .item button {
            background-color: #ff9800;
            border: none;
            color: white;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
  /* Search Bar Styling */
  .search-bar {
            width: 100%;
            max-width: 250px; /* Capped to fit navbar */
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin: 5px 0; /* Adjusted to prevent navbar growth */
        }

        .search-results {
            max-width: 250px; /* Match search bar */
            border: 1px solid #ddd;
            border-radius: 5px;
            max-height: 300px;
            overflow-y: auto;
            background: #fff;
            position: absolute;
            z-index: 1000;
            display: none;
            top: 100%;
            left: 25px; /* Align with search bar */
        }

        .search-results .result-item {
            display: flex;
            align-items: center;
            padding: 10px;
            cursor: pointer;
            border-bottom: 1px solid #eee;
        }

        .search-results .result-item:hover {
            background: #f5f5f5;
        }

        .search-results .result-item img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            margin-right: 10px;
            border-radius: 5px;
        }

        .search-results .result-item p {
            margin: 0;
            font-size: 14px;
        }

        .search-results .result-item p span {
            font-weight: bold;
        }

        .search-results .no-results, .search-results .error {
            padding: 10px;
            font-size: 14px;
        }

        .search-results .error {
            color: red;
        }
    </style>
</head>
<body>
<nav class="navbar">
        <div class="nav-left">
            <a>🔎</a> <input type="text" id="searchBar" placeholder="Search products..." class="search-bar" onkeyup="searchProducts()">
            <div id="searchResults" class="search-results"></div>
        </div>
        <div class="nav-center">
            <ul class="nav-links">
                <li><a href="home.html">Home</a></li>
                <li><a href="about us.html">About Us</a></li>
                <li><a href="story.html">Story</a></li>
            </ul>
            <div class="logo">
                <img src="Heart strings.png" alt="Cafe Niloufer">
            </div>
            <ul class="nav-links">
                <li><a href="orders.html">Orders</a></li>
                <li class="dropdown">
                    <a href="#">Shop Now</a>
                    <div class="dropdown-content">
                    
                        <a href="coffee.php">Coffee</a>
                        <a href="shakes.php">shakes</a>
                        <a href="food.php">Food</a>
                        <a href="desserts.php">Deserts</a>
                
                    </div>
                </li>
                <li class="dropdown">
                    <a href="#">Reach Us</a>
                    <div class="dropdown-content">
                        <a href="faq.html">FAQs</a>
                        <a href="contactus.html">Contact us</a>
                        <a href="review.html">Review</a>
                    </div>
                </li>
            </ul>
        </div>
        <div class="nav-right">
            <a href="login.html" class="login">Login / Register</a>
            <a href="mycart.html" class="cart-icon">🛒</a>
            <a href="profile.php">
    <i class="fa-solid fa-circle-user fa-lg" style="color: #ffffff;"></i>
</a>

        </div>
    </nav>
    
    <video autoplay muted loop id="myVideo" class ="video">
        <source src="bb.mp4" type="video/mp4" weidth="1920px" height="1080px">
      </video>
       

    <div class="menu-section">
        <h2 class="menu-title">FOOD MENU</h2>
        <div class="menu-items">
            <?php
            $conn = new mysqli("localhost", "root", "", "cafe_app");

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $category = 'food'; // ✅ Use correct category for shakes
            $sql = "SELECT * FROM menu_items WHERE category=? ORDER BY created_at DESC";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $category);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 0) {
                echo "<p>No food found.</p>";
            }

            while ($item = $result->fetch_assoc()):
                $imagePath = "uploads/" . htmlspecialchars($item['image_path']);
            ?>
                <div class="item">
                    <img src="<?php echo $imagePath; ?>" alt="<?php echo htmlspecialchars($item['item_name']); ?>">
                    <h3><?php echo htmlspecialchars($item['item_name']); ?></h3>
                    <p>₹<?php echo number_format($item['price'], 2); ?></p>
                    <button class="add-to-cart"
                        data-name="<?php echo htmlspecialchars($item['item_name']); ?>"
                        data-price="<?php echo htmlspecialchars($item['price']); ?>"
                        data-image="<?php echo $imagePath; ?>">
                        Add to Cart
                    </button>
                </div>
            <?php endwhile;

            $stmt->close();
            $conn->close();
            ?>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const buttons = document.querySelectorAll(".add-to-cart");

            buttons.forEach(btn => {
                btn.addEventListener("click", function () {
                    const name = this.dataset.name;
                    const price = parseFloat(this.dataset.price);
                    const image = this.dataset.image;

                    let cart = JSON.parse(localStorage.getItem("cart")) || {};

                    if (cart[name]) {
                        cart[name].quantity += 1;
                    } else {
                        cart[name] = { price, image, quantity: 1 };
                    }

                    localStorage.setItem("cart", JSON.stringify(cart));
                    alert(name + " added to cart!");
                    window.location.href = "";
                });
            });
        });
    </script>

</body>
</html>
