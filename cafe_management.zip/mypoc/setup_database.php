<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "cafe_app";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create users table
$usersTable = "
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

// Create orders table
$ordersTable = "
CREATE TABLE IF NOT EXISTS orders (
    orderID INT AUTO_INCREMENT PRIMARY KEY,
    customerName VARCHAR(100),
    date DATE,
    time TIME,
    numPersons INT,
    tableNumber INT,
    stateTax FLOAT,
    centralTax FLOAT,
    totalTax FLOAT,
    total FLOAT,
    employeeID INT
)";

// Create order_items table
$orderItemsTable = "
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    orderID INT,
    itemName VARCHAR(100),
    quantity INT,
    price DOUBLE,
    FOREIGN KEY (orderID) REFERENCES orders(orderID) ON DELETE CASCADE
)";

// Create menu_items table
$menuItemsTable = "
CREATE TABLE IF NOT EXISTS menu_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DOUBLE NOT NULL,
    category VARCHAR(50),
    image_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

// Create employees table
$employeesTable = "
CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(100) NOT NULL
)";

// Create contact_messages table
$contactTable = "
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    subject VARCHAR(255),
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

// Create reviews table
$reviewsTable = "
CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    rating INT,
    review_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

// Execute queries
$tables = [
    "Users" => $usersTable,
    "Orders" => $ordersTable,
    "Order Items" => $orderItemsTable,
    "Menu Items" => $menuItemsTable,
    "Employees" => $employeesTable,
    "Contact Messages" => $contactTable,
    "Reviews" => $reviewsTable
];

foreach ($tables as $name => $sql) {
    if ($conn->query($sql) === TRUE) {
        echo "✓ Table '$name' created successfully.<br>";
    } else {
        echo "✗ Error creating '$name' table: " . $conn->error . "<br>";
    }
}

$conn->close();
echo "<br><strong>Database setup completed!</strong>";
?>
