<?php
header("Content-Type: application/json");

$host = "localhost";
$dbname = "cafe_app";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Connection failed."]);
    exit();
}

$sql = "SELECT * FROM user_public_view";
$result = $conn->query($sql);

$users = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    echo json_encode(["success" => true, "users" => $users]);
} else {
    echo json_encode(["success" => true, "users" => []]);
}

$conn->close();
?>
