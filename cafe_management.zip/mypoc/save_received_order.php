<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "cafe_app"; // Replace with your actual DB name

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get POST data
$customerName = $_POST['customerName'] ?? '';
$date = $_POST['date'] ?? '';
$time = $_POST['time'] ?? '';
$numPersons = $_POST['numPersons'] ?? 0;
$tableNumber = $_POST['tableNumber'] ?? 0;
$stateTax = $_POST['stateTax'] ?? 0.0;
$centralTax = $_POST['centralTax'] ?? 0.0;
$totalTax = $_POST['totalTax'] ?? 0.0;
$total = $_POST['total'] ?? 0.0;
$orderItemsJson = $_POST['orderItems'] ?? '[]';
$orderItems = json_decode($orderItemsJson, true);

// Get random employee with role = 'Server'
$employeeID = null;
$empResult = $conn->query("SELECT employeeID FROM employees WHERE role='Server' ORDER BY RAND() LIMIT 1");
if ($empResult && $empResult->num_rows > 0) {
    $row = $empResult->fetch_assoc();
    $employeeID = $row['employeeID'];
}

// Insert into orders
$stmt = $conn->prepare("INSERT INTO orders (customerName, date, time, numPersons, tableNumber, stateTax, centralTax, totalTax, total, employeeID)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssiiidddi", $customerName, $date, $time, $numPersons, $tableNumber, $stateTax, $centralTax, $totalTax, $total, $employeeID);
$stmt->execute();
$orderID = $stmt->insert_id;
$stmt->close();

// Insert each item into order_items
if ($orderID && is_array($orderItems)) {
    $stmtItem = $conn->prepare("INSERT INTO order_items (orderID, itemName, itemPrice) VALUES (?, ?, ?)");
    foreach ($orderItems as $item) {
        $itemName = $item['name'] ?? '';
        $itemPrice = $item['price'] ?? 0.0;
        $stmtItem->bind_param("isd", $orderID, $itemName, $itemPrice);
        $stmtItem->execute();
    }
    $stmtItem->close();
}

$conn->close();
echo "Order saved successfully.";
?>
