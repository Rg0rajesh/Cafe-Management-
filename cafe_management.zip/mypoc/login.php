<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cafe_app";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 1. Create login log table if not exists
$conn->query("
    CREATE TABLE IF NOT EXISTS user_logins (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES cafe_users(id)
    )
");

// 2. Create or replace view to mask passwords and show login time
$conn->query("
    CREATE OR REPLACE VIEW user_login_view AS
    SELECT 
        u.id,
        u.first_name,
        u.last_name,
        u.phone,
        u.email,
        'xxxxxx' AS password_masked,
        l.login_time
    FROM cafe_users u
    JOIN user_logins l ON u.id = l.user_id
    ORDER BY l.login_time DESC
");

// 3. If form submitted, check credentials
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Updated query to fetch all necessary fields
    $stmt = $conn->prepare("
        SELECT id, first_name, last_name, phone, email, password_hash, 
               profile_image, area, city, state, country, pincode 
        FROM cafe_users 
        WHERE email = ?
    ");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password_hash'])) {
            // Validate phone number
            if (!preg_match('/^\d{10,15}$/', $user['phone'])) {
                echo "Invalid phone number format in your account. Please update your profile.";
                $stmt->close();
                $conn->close();
                exit;
            }

            // Store all relevant session data
            $_SESSION['user'] = [
                'id' => $user['id'],
                'first_name' => $user['first_name'],
                'last_name' => $user['last_name'],
                'phone' => $user['phone'],
                'email' => $user['email'],
                'profile_image' => $user['profile_image'],
                'area' => $user['area'],
                'city' => $user['city'],
                'state' => $user['state'],
                'country' => $user['country'],
                'pincode' => $user['pincode']
            ];
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['phone'] = $user['phone']; // Explicit phone storage
            $_SESSION['login_time'] = date("Y-m-d H:i:s");

            // Insert login log
            $userId = $user['id'];
            $stmt = $conn->prepare("INSERT INTO user_logins (user_id, login_time) VALUES (?, NOW())");
            $stmt->bind_param("i", $userId);
            $stmt->execute();

            // Redirect to profile page
            header("Location: profile.php");
            exit;
        } else {
            echo "Incorrect password.";
        }
    } else {
        echo "Email not found.";
    }

    $stmt->close();
}

$conn->close();
?>