<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'cafe_app';
$conn = new mysqli($host, $user, $pass, $db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];

    // Get image path to delete file
    $res = $conn->query("SELECT image_path FROM menu_items WHERE id = $id");
    $row = $res->fetch_assoc();
    $image = $row['image_path'];

    // Delete from DB
    if ($conn->query("DELETE FROM menu_items WHERE id = $id")) {
        // Delete file
        if (file_exists("uploads/$image")) {
            unlink("uploads/$image");
        }
        echo "success";
    } else {
        echo "error";
    }
}
?>
